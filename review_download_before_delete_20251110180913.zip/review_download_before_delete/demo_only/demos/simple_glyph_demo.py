from tools.simple_glyph_demo import main

if __name__ == '__main__':
    main()
