#!/usr/bin/env python3
"""
Simple Ritual Capsule Processor runner (delegates to tools.simple_ritual_processor.main)
"""

from tools.simple_ritual_processor import main


if __name__ == '__main__':
    main()
