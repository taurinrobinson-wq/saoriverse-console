"""Compatibility stub: import implementation from tools.consolidate_glyphs
and expose a runnable script for backwards compatibility.
"""

from tools.consolidate_glyphs import main

if __name__ == "__main__":
    main()
