"""Compatibility stub: imports the implementation from tools.integrate_glyph_lexicons
and exposes the same CLI entrypoint so existing invocation patterns continue to work.
"""

from tools.integrate_glyph_lexicons import main

if __name__ == "__main__":
    main()
