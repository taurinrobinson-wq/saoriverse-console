from tools.railway_diagnostics import main

if __name__ == '__main__':
    main()
