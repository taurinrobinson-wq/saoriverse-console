from tools.update_system import *

if __name__ == "__main__":
    main()
