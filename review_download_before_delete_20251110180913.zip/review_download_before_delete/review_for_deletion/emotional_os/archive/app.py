# Streamlit Cloud Entry Point - Authentication System v2.1
# Forces complete reload of authentication system

from emotional_os.auth.auth_emotional_os import main

if __name__ == "__main__":
    print("Loading Authentication System v2.1...")
    main()